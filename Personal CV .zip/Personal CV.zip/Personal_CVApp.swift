//
//  Personal_CVApp.swift
//  Personal CV
//
//  Created by Nikos Galinos on 13/5/23.
//

import SwiftUI

@main
struct Personal_CVApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
